//
//  Bridge-Header.h
//  manee
//
//  Created by Phudit Chuengjaroen on 6/10/15.
//  Copyright (c) 2015 Phudit Chuengjaroen. All rights reserved.
//

#ifndef manee_Bridge_Header_h
#define manee_Bridge_Header_h

#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <FBSDKShareKit/FBSDKShareKit.h>

#endif
